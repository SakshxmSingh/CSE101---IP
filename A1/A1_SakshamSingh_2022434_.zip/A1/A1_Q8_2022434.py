# Saksham Singh
# 2022434
# Section B,  Group 7
# IP Assignment 01

#--------------ques08-------------------
def sum(list):
    sum=0
    for i in list:
        sum+=i
    return sum*1000000


pop = [50, 1450, 1400, 1700, 1500, 600, 1200]
growth_rate =[]
for i in range(0,len(pop)):
    growth_rate.insert(i, (2.5 - 0.4*i)/100)

sum_pop=[0]
sum_pop.append(sum(pop))
years = [0,0]

for i in range(0,len(sum_pop)):
    while sum_pop[i+1]>=sum_pop[i]:
        for j in range(0,len(pop)):
            pop[j]=pop[j]+(pop[j]*growth_rate[j])
        sum_pop.append(sum(pop))
        years.append(len(years)+1)
        growth_rate = [i-0.001 for i in growth_rate]
        i+=1


print("max population is",round(max(sum_pop)/1000000000, 5),"billions and it is reached in",years[sum_pop.index(max(sum_pop))]-2,"years")





            

