# Saksham Singh
# 2022434
# Section B,  Group 7
# IP Assignment 01

#--------------ques06-------------------

n = int(input())
for i in range(1,n+1):
    print("*"*i+" "*(2*n-2*i)+"*"*i)